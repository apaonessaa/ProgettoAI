docker run -it -v ~/Desktop/ProgettoAI:/workspace/ProgettoAI --name planutils aiplanning/planutils
planutils activate
(planutils) root@bf885b8679bc:/workspace/ProgettoAI/punto1$ ff domain.pddl ./problems/p01.pddl